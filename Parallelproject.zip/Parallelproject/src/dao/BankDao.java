package dao;
import java.util.HashMap;

import bean.BankBean;

public class BankDao {

BankBean beankBeanObj;
	
	HashMap<Long, BankBean> hm = new HashMap<Long, BankBean>();
	
	public void addCustomer(BankBean beankBeanObj) {			// method to ad a customer 
		this.beankBeanObj = beankBeanObj;						// by saving the bank bean object
		hm.put(beankBeanObj.getAccNo(), beankBeanObj);			// in hash map
	}
	
	public HashMap<Long, BankBean> hm(){						// method to return hash map object
		return hm;
	}
}

